#!/bin/bash
python3 lmc_chill_bot.py
